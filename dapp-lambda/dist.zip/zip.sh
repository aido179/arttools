zip -qq -r dist.zip .
