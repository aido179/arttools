# AWS Lambda based dapp API.

# deployment:
1. Build the dist zip: `source zip.sh`
2. Log in to lambda, and upload the zip.
